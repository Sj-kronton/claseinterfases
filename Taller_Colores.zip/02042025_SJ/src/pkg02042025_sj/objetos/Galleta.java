/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg02042025_sj.objetos;

/**
 *
 * @author A12
 */
public class Galleta {
    //atributes
    String color;
    String textura;
    String sabor;
    String tama�o;
    int forma;
   
     //construct
    public Galleta(){

    }
    //metods  
    public void assault (){
        System.out.println("Saboreando");    
    }  
    public String getcolor(){
        return color;
    }
    public void setcolor(String color){
        this.color = color;
    }
     public String gettextura(){
        return textura;
    }
    public void settextura(String textura){
        this.textura = textura;
    }
     public String getsabor(){
        return sabor;
    }
    public void setsabor(String sabor){
        this.sabor = sabor;
    }
     public String gettama�o(){
        return tama�o;
    }
    public void settama�o(String tama�o){
        this.tama�o = tama�o;
    }    
    public int getforma(){
        return forma;
    }
    public void setforma(int forma){
        this.forma = forma;
       
    }
}
