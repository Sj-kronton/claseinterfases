/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg02042025_sj.objetos;

/**
 *
 * @author A12
 */
public class Robot {
    private String nombre;
    private String modelo;
    private int bateria;
    private String estado;
    private double peso;


    public Robot() {
        this.nombre = nombre;
        this.modelo = modelo;
        this.bateria = bateria;
        this.estado = estado;
        this.peso = peso;
    }

   
    public String getNombre() {
        return nombre;
    }

    public String getModelo() {
        return modelo;
    }

    public int getBateria() {
        return bateria;
    }

    public String getEstado() {
        return estado;
    }

    public double getPeso() {
        return peso;
    }

   
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setBateria(int bateria) {
        this.bateria = bateria;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    
    public void cargar() {
        this.bateria = 100;
        System.out.println(this.nombre + " est� completamente cargado.");
    }

    public void encender() {
        if (this.bateria > 0) {
            this.estado = "activo";
            System.out.println(this.nombre + " ha sido encendido.");
        } else {
            System.out.println(this.nombre + " no tiene suficiente bater�a para encenderse.");
        }
    }

    public void realizarAccion(String accion) {
        if (this.estado.equals("activo") && this.bateria > 0) {
            System.out.println(this.nombre + " est� realizando la acci�n: " + accion);
            this.bateria -= 10;
        } else if (this.bateria <= 0) {
            System.out.println(this.nombre + " no tiene suficiente bater�a para realizar la acci�n.");
        } else {
            System.out.println(this.nombre + " est� inactivo y no puede realizar acciones.");
        }
    }

    public void mostrarEstado() {
        System.out.println(this.nombre + " - Estado: " + this.estado + ", Bater�a: " + this.bateria + "%, Peso: " + this.peso + "kg");
    }

   
    public void reducirPeso(double cantidad) {
        if (cantidad > 0 && this.peso - cantidad >= 0) {
            this.peso -= cantidad;
            System.out.println(this.nombre + " ha reducido su peso en " + cantidad + "kg. Peso actual: " + this.peso + "kg");
        } else {
            System.out.println("No se puede reducir el peso en esa cantidad.");
        }
    }

    public void actualizarFirmware() {
        System.out.println(this.nombre + " est� actualizando su firmware...");
        System.out.println("Actualizaci�n completada.");
    }

    public void apagar() {
        this.estado = "inactivo";
        System.out.println(this.nombre + " ha sido apagado.");
    }

    public void verificarBateria() {
        if (this.bateria > 50) {
            System.out.println(this.nombre + " tiene suficiente bater�a.");
        } else {
            System.out.println(this.nombre + " tiene bater�a baja, considera cargarlo.");
        }
    }

    public void mover(String direccion, int distancia) {
        if (this.estado.equals("activo") && this.bateria > 0) {
            System.out.println(this.nombre + " se ha movido " + distancia + " metros hacia " + direccion + ".");
            this.bateria -= 5;
        } else {
            System.out.println(this.nombre + " no puede moverse en este momento.");
        }
    }

    public static void main(String[] args) {
        
        Robot robot1 = new Robot("RoboX", "RX-2000", 50, "inactivo", 75.5);

        
        System.out.println("Nombre del robot: " + robot1.getNombre());

       
        robot1.mostrarEstado();
        robot1.encender();
        robot1.realizarAccion("barrer");
        robot1.verificarBateria();
        robot1.mover("adelante", 10);
        robot1.reducirPeso(5);
        robot1.actualizarFirmware();
        robot1.apagar();
    }
}
