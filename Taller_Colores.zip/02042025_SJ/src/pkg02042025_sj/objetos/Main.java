/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg02042025_sj.objetos;

// Valeria Andrea lozano pimiento
// Juan Camilo villamizar
// Juan Alejandro Sierra Rinc�n
public class Main {

   
    public static void main(String args []) {
            computador fede = new computador();
            Galleta jengibre = new Galleta();
            Robot tuercas = new Robot();
            fede.Pantalla("SI");
            fede.prendido();
            jengibre.assault();
            tuercas.cargar();
    }
    
}
