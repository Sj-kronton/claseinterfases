/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg02042025_sj.objetos;

import javax.swing.JOptionPane;

/**
 *
 * @author A12
 */
public class computador {
    //atributos
    String Imagen;
    String Contrase�a;
    boolean corriente;
    int Codigo;
    String Nombre;
    //constructores
    public computador (){
    }
    //
    public String getImagen(){
        return Imagen;
    }
    public void Pantalla(String imagen_pantalla){
        this.Imagen=imagen_pantalla;
    }
    public boolean getCorriente(){
        return corriente;
    }
    public int Getcodigo(){
        return Codigo;
    }
    public void mostrarpantalla(){
        JOptionPane.showInternalMessageDialog(null, this.Imagen,"Pantalla:", JOptionPane.PLAIN_MESSAGE);
    }
    public void iniciarsesion(){
        if ("123".equals(this.Contrase�a)){
            JOptionPane.showInternalMessageDialog(null, "contrase�a correcta","Sesion iniciada", JOptionPane.PLAIN_MESSAGE);
        }
    }
    public void prendido(){
        JOptionPane.showInternalMessageDialog(null, this.corriente,"Hay corriente?", JOptionPane.PLAIN_MESSAGE);
    }
    public void sistema(){
        JOptionPane.showInternalMessageDialog(null, this.Codigo,"Codigo sistema operativo", JOptionPane.PLAIN_MESSAGE);
    }
    public void due�o(){
        JOptionPane.showInternalMessageDialog(null, this.Nombre,"Perfil del PC: ", JOptionPane.PLAIN_MESSAGE);
    }
}

